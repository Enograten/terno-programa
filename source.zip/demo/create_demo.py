from pathlib import Path
import sys
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import cv2
import numpy as np
from src.thermal_reader import ThermalData
from src.visualization import thermal_rgb, png_bytes


def create_demo():
    y, x = np.mgrid[:480, :640]
    matrix = 28 + .12*np.sin(x/29) + .09*np.cos(y/37) + .05*x/640
    # Two explicitly synthetic objects; not a clinical example.
    left = ((x-195)/85)**2 + ((y-240)/150)**2
    right = ((x-445)/76)**2 + ((y-249)/141)**2
    matrix[left <= 1] = 32 + 2*(1-left[left <= 1])
    matrix[right <= 1] = 30 + 2*(1-right[right <= 1])
    rgb = thermal_rgb(matrix)
    marked = rgb.copy()
    cv2.ellipse(marked, (195,240), (73,134), 0, 0, 360, (255,0,0), 4, cv2.LINE_AA)
    cv2.ellipse(marked, (445,249), (65,126), 0, 0, 360, (255,0,0), 4, cv2.LINE_AA)
    return ThermalData(matrix, rgb, "demo_temperature.npy", "demo",
                       {"synthetic": True, "units": "C", "description": "Two synthetic warm ellipses"}), marked


def main():
    folder = Path(__file__).resolve().parent
    thermal, marked = create_demo()
    np.save(folder/"temperature.npy", thermal.temperatures)
    np.savetxt(folder/"temperature.csv", thermal.temperatures, delimiter=",", fmt="%.8f")
    (folder/"original.png").write_bytes(png_bytes(thermal.reference))
    (folder/"marked.png").write_bytes(png_bytes(marked))
    print("Demo generated: 640 x 480; demo/temperature.npy, original.png, marked.png")


if __name__ == "__main__":
    main()
