from pathlib import Path
from datetime import datetime, timezone
import csv
import hashlib
import io
import json
import os
import numpy as np
from .visualization import png_bytes
from .analyzer import compare_regions


def csv_bytes(report):
    buffer = io.StringIO(newline="")
    rows = []
    for region in report["regions"]:
        rows.append({"analysis_id": report["analysis_id"],
                     "original_file_name": report["original_file_name"],
                     "patient_id": report["patient_id"], "measurement_date": report["measurement_date"],
                     "session": report.get("session", ""), "measurement_conditions": report.get("measurement_conditions", ""),
                     "date": report["created_at"], "source": report["source"], **region})
    if rows:
        writer = csv.DictWriter(buffer, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            # Preserve numeric fields, prevent text labels being read as Excel formulas.
            writer.writerow({k: ("'"+v if isinstance(v, str) and v[:1] in ("=", "+", "-", "@") else v)
                             for k, v in row.items()})
    return buffer.getvalue().encode("utf-8-sig")


def json_bytes(report):
    return json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False).encode("utf-8")


def build_report(analysis, selected, threshold, patient_id, measurement_date, names, pair=None, session="", measurement_conditions=""):
    rows = analysis.rows(selected, threshold, names)
    # Session-state Analysis instances may retain an older rows() implementation
    # after a Streamlit code reload. Normalize derived fields at the report boundary.
    rows = [{**row, "temperature_range_c": float(row["max_temperature"] - row["min_temperature"])}
            for row in rows]
    if len(set(r["region_name"].strip().casefold() for r in rows)) != len(rows):
        from .errors import AnalysisError
        raise AnalysisError("Назви областей повинні відрізнятися.")
    comparison = None
    if pair:
        by_id = {row["region_id"]: row for row in rows}
        if len(pair) != 2 or pair[0] == pair[1] or any(key not in by_id for key in pair):
            from .errors import AnalysisError
            raise AnalysisError("Для порівняння виберіть дві різні виміряні області.")
        comparison = compare_regions(by_id[pair[0]], by_id[pair[1]])
        comparison["name_a"] = names.get(pair[0], pair[0])
        comparison["name_b"] = names.get(pair[1], pair[1])
    return {"schema_version": 1, "analysis_id": analysis.analysis_id, "created_at": analysis.created_at,
            "original_file_name": analysis.thermal.filename, "source": analysis.thermal.source,
            "units": "C", "patient_id": patient_id.strip(), "measurement_date": str(measurement_date),
            "session": session.strip(), "measurement_conditions": measurement_conditions.strip(),
            "matrix_shape": list(analysis.thermal.temperatures.shape),
            "marked_sha256": analysis.marked_sha256, "geometry": analysis.geometry,
            "metadata": analysis.thermal.metadata, "warnings": analysis.warnings,
            "regions": rows, "comparison": comparison,
            "conventions": {"boundary": "strict interior; drawn stroke excluded",
                            "std": "population ddof=0", "hot_area": "temperature > threshold",
                            "percent_difference": "100*abs(A-B)/mean(A+273.15,B+273.15)"}}


def save_report(root, analysis, report):
    root = Path(root)
    for name in ("masks", "overlays", "results", "temperature_matrices"):
        (root/name).mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256(json_bytes(report)).hexdigest()[:12]
    run_id = report["analysis_id"]+"_"+digest
    destination = root/"results"/(run_id+".json")
    if destination.exists():
        return destination
    saved = dict(report)
    paths = {"masks": {}, "overlay": f"overlays/{run_id}.png",
             "matrix": f"temperature_matrices/{run_id}.npy"}
    for index, row in enumerate(report["regions"], 1):
        relative = f"masks/{run_id}_region_{index}.png"
        (root/relative).write_bytes(png_bytes(analysis.regions[row["region_id"]].astype(np.uint8)*255))
        paths["masks"][row["region_id"]] = relative
    (root/paths["overlay"]).write_bytes(png_bytes(analysis.overlay([r["region_id"] for r in report["regions"]])))
    np.save(root/paths["matrix"], analysis.thermal.temperatures, allow_pickle=False)
    saved["artifacts"] = paths
    saved["saved_at"] = datetime.now(timezone.utc).isoformat()
    (root/"results"/(run_id+".csv")).write_bytes(csv_bytes(saved))
    temp = destination.with_suffix(".json.tmp")
    temp.write_bytes(json_bytes(saved))
    os.replace(temp, destination)
    return destination


def load_history(root):
    reports = []
    for path in sorted((Path(root)/"results").glob("*.json")):
        try:
            if path.stat().st_size > 5_000_000:
                continue
            record = json.loads(path.read_text(encoding="utf-8"))
            if record.get("schema_version") == 1 and "regions" in record:
                reports.append(record)
        except (OSError, ValueError):
            continue
    return reports
