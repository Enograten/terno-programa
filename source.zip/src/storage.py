from pathlib import Path
from datetime import datetime, timezone
import csv
import hashlib
import io
import json
import os
import numpy as np
from .visualization import png_bytes
from .analyzer import compare_regions


def csv_bytes(report):
    buffer = io.StringIO(newline="")
    rows = []
    for region in report["regions"]:
        rows.append({"analysis_id": report["analysis_id"],
                     "original_file_name": report["original_file_name"],
                     "patient_id": report["patient_id"], "measurement_date": report["measurement_date"],
                     "session": report.get("session", ""), "measurement_conditions": report.get("measurement_conditions", ""),
                     "date": report["created_at"], "source": report["source"], **region})
    if rows:
        writer = csv.DictWriter(buffer, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            # Preserve numeric fields, prevent text labels being read as Excel formulas.
            writer.writerow({k: ("'"+v if isinstance(v, str) and v[:1] in ("=", "+", "-", "@") else v)
                             for k, v in row.items()})
    return buffer.getvalue().encode("utf-8-sig")


def json_bytes(report):
    return json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False).encode("utf-8")


def build_report(analysis, selected, threshold, patient_id, measurement_date, names, pair=None, session="", measurement_conditions=""):
    rows = analysis.rows(selected, threshold, names)
    # Session-state Analysis instances may retain an older rows() implementation
    # after a Streamlit code reload. Normalize derived fields at the report boundary.
    rows = [{**row, "temperature_range_c": float(row["max_temperature"] - row["min_temperature"]),
                     "variance_c2": float(row.get("variance_c2", row["std"] ** 2))}
            for row in rows]
    if len(set(r["region_name"].strip().casefold() for r in rows)) != len(rows):
        from .errors import AnalysisError
        raise AnalysisError("Назви областей повинні відрізнятися.")
    comparison = None
    if pair:
        by_id = {row["region_id"]: row for row in rows}
        if len(pair) != 2 or pair[0] == pair[1] or any(key not in by_id for key in pair):
            from .errors import AnalysisError
            raise AnalysisError("Для порівняння виберіть дві різні виміряні області.")
        comparison = compare_regions(by_id[pair[0]], by_id[pair[1]])
        comparison["name_a"] = names.get(pair[0], pair[0])
        comparison["name_b"] = names.get(pair[1], pair[1])
    return {"schema_version": 1, "analysis_id": analysis.analysis_id, "created_at": analysis.created_at,
            "original_file_name": analysis.thermal.filename, "source": analysis.thermal.source,
            "units": "C", "patient_id": patient_id.strip(), "measurement_date": str(measurement_date),
            "session": session.strip(), "measurement_conditions": measurement_conditions.strip(),
            "matrix_shape": list(analysis.thermal.temperatures.shape),
            "marked_sha256": analysis.marked_sha256, "geometry": analysis.geometry,
            "metadata": analysis.thermal.metadata, "warnings": analysis.warnings,
            "regions": rows, "comparison": comparison,
            "conventions": {"boundary": "strict interior; drawn stroke excluded",
                            "variance_c2": "population ddof=0; degrees Celsius squared",
                            "std": "population ddof=0", "hot_area": "temperature > threshold",
                            "percent_difference": "100*abs(A-B)/mean(A+273.15,B+273.15)"}}


def save_report(root, analysis, report):
    root = Path(root)
    for name in ("masks", "overlays", "results", "temperature_matrices"):
        (root/name).mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256(json_bytes(report)).hexdigest()[:12]
    run_id = report["analysis_id"]+"_"+digest
    destination = root/"results"/(run_id+".json")
    if destination.exists():
        return destination
    saved = dict(report)
    paths = {"masks": {}, "overlay": f"overlays/{run_id}.png",
             "matrix": f"temperature_matrices/{run_id}.npy"}
    for index, row in enumerate(report["regions"], 1):
        relative = f"masks/{run_id}_region_{index}.png"
        (root/relative).write_bytes(png_bytes(analysis.regions[row["region_id"]].astype(np.uint8)*255))
        paths["masks"][row["region_id"]] = relative
    (root/paths["overlay"]).write_bytes(png_bytes(analysis.overlay([r["region_id"] for r in report["regions"]])))
    np.save(root/paths["matrix"], analysis.thermal.temperatures, allow_pickle=False)
    saved["artifacts"] = paths
    saved["saved_at"] = datetime.now(timezone.utc).isoformat()
    (root/"results"/(run_id+".csv")).write_bytes(csv_bytes(saved))
    temp = destination.with_suffix(".json.tmp")
    temp.write_bytes(json_bytes(saved))
    os.replace(temp, destination)
    return destination


def load_history(root):
    reports = []
    for path in sorted((Path(root)/"results").glob("*.json")):
        try:
            if path.stat().st_size > 5_000_000:
                continue
            record = json.loads(path.read_text(encoding="utf-8"))
            if record.get("schema_version") == 1 and "regions" in record and not record.get("deleted"):
                record["_history_key"] = path.name
                reports.append(record)
        except (OSError, ValueError):
            continue
    return reports


def edit_history_record(root, record, region_id, changes=None, delete=False):
    """Update one persisted report; never change measured temperatures or artifacts."""
    import copy
    from datetime import date
    from .errors import AnalysisError
    key = record.get("_history_key", "")
    if not key or Path(key).name != key or not key.endswith(".json"):
        raise AnalysisError("Запис не має коректного ідентифікатора. Оновіть історію.")
    destination = Path(root)/"results"/key
    if not destination.is_file():
        raise AnalysisError("Запис уже недоступний. Оновіть історію.")
    current = json.loads(destination.read_text(encoding="utf-8"))
    if current.get("deleted"):
        raise AnalysisError("Запис уже видалено.")
    updated = copy.deepcopy(current)
    region = next((r for r in updated["regions"] if r["region_id"] == region_id), None)
    if region is None:
        raise AnalysisError("Область уже недоступна.")
    if delete:
        updated["regions"] = [r for r in updated["regions"] if r["region_id"] != region_id]
        updated["deleted"] = not updated["regions"]
        comparison = updated.get("comparison")
        if comparison and region_id in (comparison["region_a"], comparison["region_b"]):
            updated["comparison"] = None
    else:
        changes = changes or {}
        if set(changes) != {"patient_id", "measurement_date", "session", "measurement_conditions", "region_name"}:
            raise AnalysisError("Можна змінювати лише описові дані запису.")
        if not changes["patient_id"].strip() or not changes["region_name"].strip():
            raise AnalysisError("Учасник і назва ділянки не можуть бути порожніми.")
        date.fromisoformat(str(changes["measurement_date"]))
        name = changes["region_name"].strip()
        if any(r["region_id"] != region_id and r["region_name"].strip().casefold() == name.casefold() for r in updated["regions"]):
            raise AnalysisError("Назви ділянок одного аналізу повинні відрізнятися.")
        for field in ("patient_id", "measurement_date", "session", "measurement_conditions"):
            updated[field] = str(changes[field]).strip()
        region["region_name"] = name
        comparison = updated.get("comparison")
        if comparison:
            for side in ("a", "b"):
                if comparison["region_"+side] == region_id:
                    comparison["name_"+side] = name
    updated["updated_at"] = datetime.now(timezone.utc).isoformat()
    # Keep recoverable prior versions locally, including deleted rows.
    backup = Path(root)/"history_backups"
    backup.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%f")
    (backup/(destination.stem+"_"+stamp+".json")).write_bytes(json_bytes(current))
    csv_path = destination.with_suffix(".csv")
    csv_tmp = csv_path.with_suffix(".csv.tmp")
    csv_tmp.write_bytes(csv_bytes(updated))
    temp = destination.with_suffix(".json.tmp")
    temp.write_bytes(json_bytes(updated))
    _replace_with_retry(csv_tmp, csv_path)
    _replace_with_retry(temp, destination)
    return updated


HISTORY_API_VERSION = 2

def _replace_with_retry(source, destination):
    # Windows indexing/antivirus may briefly lock a freshly written file.
    import time
    for attempt in range(6):
        try:
            os.replace(source, destination)
            return
        except PermissionError:
            if attempt == 5:
                raise
            time.sleep(.05 * (attempt + 1))
