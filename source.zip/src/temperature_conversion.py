"""FLIR LWIR conversion. Full object-to-window atmospheric path; window at sensor.

See SOURCES.md for equations and validation data. Calibration constants are never
invented. No colour value is ever used to calculate a temperature.
"""
from dataclasses import dataclass, asdict
import numpy as np
from .errors import AnalysisError


@dataclass(frozen=True)
class Parameters:
    PlanckR1: float
    PlanckR2: float
    PlanckB: float
    PlanckF: float
    PlanckO: float
    Emissivity: float
    ObjectDistance: float
    ReflectedApparentTemperature: float
    AtmosphericTemperature: float
    IRWindowTemperature: float
    IRWindowTransmission: float
    RelativeHumidity: float
    AtmosphericTransAlpha1: float
    AtmosphericTransAlpha2: float
    AtmosphericTransBeta1: float
    AtmosphericTransBeta2: float
    AtmosphericTransX: float

    @classmethod
    def from_metadata(cls, metadata):
        missing = [k for k in cls.__dataclass_fields__ if k not in metadata]
        if missing:
            raise AnalysisError("У FLIR-файлі відсутні параметри для перерахунку: " + ", ".join(missing))
        try:
            values = {k: float(metadata[k]) for k in cls.__dataclass_fields__}
        except (TypeError, ValueError) as exc:
            raise AnalysisError("Некоректні числові параметри FLIR.") from exc
        # ExifTool -n reports humidity as a fraction (0..1).
        values["RelativeHumidity"] *= 100.0
        p = cls(**values)
        p.validate()
        return p

    def validate(self):
        if not all(np.isfinite(v) for v in asdict(self).values()):
            raise AnalysisError("Параметри FLIR містять NaN або Infinity.")
        if min(self.PlanckR1, self.PlanckR2, self.PlanckB) <= 0:
            raise AnalysisError("Некоректні коефіцієнти Planck.")
        if not (0 < self.Emissivity <= 1 and 0 < self.IRWindowTransmission <= 1):
            raise AnalysisError("Emissivity та IRWindowTransmission мають бути в межах (0; 1].")
        if not (0 <= self.RelativeHumidity <= 100 and 0 <= self.ObjectDistance <= 10000):
            raise AnalysisError("Некоректна вологість або відстань.")
        for name in ("ReflectedApparentTemperature", "AtmosphericTemperature", "IRWindowTemperature"):
            if not -100 < getattr(self, name) < 1000:
                raise AnalysisError("Некоректна температура середовища: " + name)


def blackbody_signal(celsius, p):
    return p.PlanckR1 / (p.PlanckR2 * (np.exp(p.PlanckB / (np.asarray(celsius) + 273.15)) - p.PlanckF)) - p.PlanckO


def atmospheric_transmission(p):
    a = p.AtmosphericTemperature
    water = p.RelativeHumidity / 100 * np.exp(1.5587 + .06939*a - .00027816*a*a + .00000068455*a*a*a)
    distance = np.sqrt(p.ObjectDistance)
    tau = p.AtmosphericTransX * np.exp(-distance * (p.AtmosphericTransAlpha1 + p.AtmosphericTransBeta1*np.sqrt(water)))
    tau += (1-p.AtmosphericTransX) * np.exp(-distance * (p.AtmosphericTransAlpha2 + p.AtmosphericTransBeta2*np.sqrt(water)))
    if not np.isfinite(tau) or not 0 < tau <= 1.000001:
        raise AnalysisError("Параметри атмосфери дають некоректне пропускання.")
    return float(min(tau, 1))


def raw_to_celsius(raw, p):
    p.validate()
    tau = atmospheric_transmission(p)
    e, w = p.Emissivity, p.IRWindowTransmission
    reflected = (1-e)/e * blackbody_signal(p.ReflectedApparentTemperature, p)
    atmosphere = (1-tau)/(e*tau) * blackbody_signal(p.AtmosphericTemperature, p)
    window = (1-w)/(e*tau*w) * blackbody_signal(p.IRWindowTemperature, p)
    object_signal = np.asarray(raw, dtype=np.float64)/(e*tau*w) - reflected - atmosphere - window
    with np.errstate(divide="ignore", invalid="ignore", over="ignore"):
        argument = p.PlanckR1/(p.PlanckR2*(object_signal + p.PlanckO)) + p.PlanckF
        result = p.PlanckB / np.log(argument) - 273.15
    result = np.where((argument > 1) & (object_signal + p.PlanckO > 0), result, np.nan)
    if np.isfinite(result).mean() < .99:
        raise AnalysisError("RAW-дані не узгоджуються з калібруванням FLIR. Перевірте формат та порядок байтів.")
    return result
