class AnalysisError(ValueError):
    """A user-facing validation error; no measurement should be produced."""


class RawByteOrderError(AnalysisError):
    """The RAW payload is valid, but metadata cannot resolve PNG byte order."""
