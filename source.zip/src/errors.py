class AnalysisError(ValueError):
    """A user-facing validation error; no measurement should be produced."""
