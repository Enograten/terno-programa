import io
import cv2
import numpy as np
from PIL import Image

COLORS = [(28, 230, 179), (96, 173, 255), (248, 204, 72), (219, 129, 255)]


def thermal_rgb(matrix):
    finite = matrix[np.isfinite(matrix)]
    lo, hi = float(finite.min()), float(finite.max())
    normalized = np.nan_to_num((matrix-lo)/max(hi-lo, 1e-6))
    # Cividis has no saturated red, making manual red annotations easy to see.
    import matplotlib
    rgba = matplotlib.colormaps["cividis"](np.clip(normalized, 0, 1))
    return np.round(rgba[:, :, :3]*255).astype(np.uint8)


def png_bytes(rgb):
    buffer = io.BytesIO()
    Image.fromarray(rgb).save(buffer, format="PNG")
    return buffer.getvalue()


def overlay_regions(rgb, regions):
    out = rgb.copy()
    for index, (region_id, mask) in enumerate(regions.items()):
        color = np.array(COLORS[index % len(COLORS)])
        out[mask] = np.round(out[mask]*.62 + color*.38).astype(np.uint8)
        contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(out, contours, -1, tuple(int(c) for c in color), 2)
        yy, xx = np.nonzero(mask)
        if len(xx):
            origin = (int(xx.mean()), int(yy.mean()))
            cv2.putText(out, region_id, origin, cv2.FONT_HERSHEY_SIMPLEX, .55, (15, 22, 30), 3, cv2.LINE_AA)
            cv2.putText(out, region_id, origin, cv2.FONT_HERSHEY_SIMPLEX, .55, tuple(int(c) for c in color), 1, cv2.LINE_AA)
    return out
