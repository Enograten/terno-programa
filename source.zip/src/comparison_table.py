"""One row per saved ROI; preserve repeated sessions and legacy records."""
import csv
import io


def comparison_rows(records):
    rows = []
    ordered = sorted(records, key=lambda r: (r["measurement_date"], r.get("saved_at", r["created_at"])))
    for record in ordered:
        for region in record["regions"]:
            rows.append({
                "Учасник": record["patient_id"], "Ділянка": region["region_name"],
                "Дата": record["measurement_date"], "Сеанс": record.get("session", ""),
                "Умови вимірювання": record.get("measurement_conditions", ""),
                "Середня, °C": region["mean_temperature"],
                "Мінімум, °C": region["min_temperature"],
                "Максимум, °C": region["max_temperature"],
                "SD, °C": region["std"],
                "Діапазон, °C": region["max_temperature"]-region["min_temperature"],
                "Пікселів": region["pixel_count"],
                "Файл": record["original_file_name"], "Аналіз": record["analysis_id"],
            })
    return rows


def comparison_csv(rows):
    buffer = io.StringIO(newline="")
    if rows:
        writer = csv.DictWriter(buffer, fieldnames=list(rows[0]), delimiter=";")
        writer.writeheader()
        for row in rows:
            safe = {}
            for key, value in row.items():
                if isinstance(value, str) and value.lstrip()[:1] in ("=", "+", "-", "@"):
                    value = "'" + value
                safe[key] = value
            writer.writerow(safe)
    return buffer.getvalue().encode("utf-8-sig")
