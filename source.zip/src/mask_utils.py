import cv2
import numpy as np
from .errors import AnalysisError
from .contour_detector import annotation_mask

GEOMETRY_ERROR = ("Зображення не відповідає оригіналу: можливі обрізка, поворот, "
                  "віддзеркалення, інша палітра або інший кадр. Використайте незмінену копію еталона.")


def check_aspect(source_shape, target_shape):
    sh, sw = source_shape[:2]
    th, tw = target_shape[:2]
    # Integer rounding up to one pixel is allowed for proportional resizes.
    if abs(sw/sh-tw/th) > max(1/sh, 1/th):
        raise AnalysisError("Співвідношення сторін змінилося. " + GEOMETRY_ERROR)


def resize_mask(mask, shape):
    check_aspect(mask.shape, shape)
    resized = cv2.resize(mask.astype(np.uint8), (shape[1], shape[0]), interpolation=cv2.INTER_NEAREST).astype(bool)
    if resized.sum() < 4:
        raise AnalysisError("Область занадто мала у координатах теплового сенсора.")
    return resized


def verify_pair(reference, marked, color="red"):
    check_aspect(reference.shape, marked.shape)
    ref = cv2.resize(reference, (marked.shape[1], marked.shape[0]), interpolation=cv2.INTER_LINEAR)
    ink = annotation_mask(marked, ref, color)
    excluded = cv2.dilate(ink.astype(np.uint8), np.ones((9, 9), np.uint8)).astype(bool)
    valid = ~excluded
    if valid.mean() < .65:
        raise AnalysisError("Занадто велика частина зображення закрита обведенням.")
    diff = np.abs(marked.astype(np.float32)-ref.astype(np.float32)).max(axis=2)
    values = diff[valid]
    if np.median(values) > 5 or np.percentile(values, 95) > 22 or (values > 35).mean() > .025:
        raise AnalysisError(GEOMETRY_ERROR)
    gray = cv2.cvtColor(ref, cv2.COLOR_RGB2GRAY).astype(np.float32)
    other = cv2.cvtColor(marked, cv2.COLOR_RGB2GRAY).astype(np.float32)
    if np.std(gray[valid]) < 4:
        raise AnalysisError("Недостатньо деталей для перевірки геометрії. Використайте контрастніший еталон.")
    if np.max(values) <= 2:
        return {"method": "pixel_identity_outside_ink", "resized": reference.shape != marked.shape,
                "mean_rgb_error": float(values.mean())}
    # Estimate affine motion solely to REJECT it; never warp the ROI automatically.
    scale = min(1.0, 800/max(gray.shape))
    size = (round(gray.shape[1]*scale), round(gray.shape[0]*scale))
    a = cv2.resize(gray, size)
    b = cv2.resize(other, size)
    allowed = cv2.resize(valid.astype(np.uint8)*255, size, interpolation=cv2.INTER_NEAREST)
    try:
        score, warp = cv2.findTransformECC(a, b, np.eye(2, 3, dtype=np.float32),
                         cv2.MOTION_AFFINE, (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 80, 1e-6),
                         allowed, 5)
    except cv2.error as exc:
        raise AnalysisError("Не вдалося надійно перевірити геометрію. " + GEOMETRY_ERROR) from exc
    points = np.array([[0,0,1], [size[0]-1,0,1], [0,size[1]-1,1], [size[0]-1,size[1]-1,1]], dtype=np.float32)
    movement = np.linalg.norm(points @ warp.T-points[:, :2], axis=1).max()/scale
    # In sensor/reference pixels, allow less than one pixel of registration uncertainty.
    reference_scale = reference.shape[1]/marked.shape[1]
    if score < .975 or movement*reference_scale > .85:
        raise AnalysisError(GEOMETRY_ERROR)
    return {"method": "pixel_comparison_and_affine_rejection", "resized": reference.shape != marked.shape,
            "mean_rgb_error": float(values.mean()), "ecc": float(score),
            "max_displacement_reference_px": float(movement*reference_scale)}


def validate_flir_preview(preview, temperatures, metadata, allow_overlays=False):
    """Conservative check for a pure full-frame thermal JPEG preview.

    This check does NOT derive temperatures from RGB. It only accepts a nearly
    monotonic palette with edge alignment to the separately decoded RAW matrix.
    Unverifiable MSX/PIP, overlays and palettes require the canonical export.
    """
    check_aspect(preview.shape, temperatures.shape)
    if float(metadata.get("DigitalZoomRatio", 1) or 1) not in (0, 1):
        raise AnalysisError("Цифровий zoom FLIR: обведіть еталон, експортований з матриці.")
    h, w = temperatures.shape
    rgb = cv2.resize(preview, (w, h), interpolation=cv2.INTER_AREA)
    lum = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY).astype(np.float32)
    valid = np.isfinite(temperatures)
    if valid.mean() < .99:
        raise AnalysisError("RAW contains invalid pixels; use the exported matrix reference.")
    # FLIR previews often overlay a scale and labels near the frame borders.
    # Validate only the central image and restrict preview-based ROIs to it.
    x0, y0, x1, y1 = round(w*.06), round(h*.08), round(w*.90), round(h*.92)
    valid[:y0] = False
    valid[y1:] = False
    valid[:, :x0] = False
    valid[:, x1:] = False
    if valid.mean() < .65 or np.std(lum[valid]) < 8 or np.std(temperatures[valid]) < .15:
        raise AnalysisError("Неможливо перевірити відповідність прев'ю FLIR та RAW.")
    # Tied-rank Spearman correlation, independent of palette range.
    import pandas as pd
    t = pd.Series(temperatures[valid]).rank().to_numpy()
    v = pd.Series(lum[valid]).rank().to_numpy()
    rho = float(np.corrcoef(t, v)[0, 1])
    if abs(rho) < (.95 if allow_overlays else .97):
        raise AnalysisError("Прев'ю FLIR не підтверджене як повний thermal-кадр. Обведіть еталон з матриці.")
    # Nonlinear lookup establishes an expected luminance field, then ECC detects
    # small crop/zoom/translation that a global rank correlation alone can miss.
    edges = np.quantile(temperatures[valid], np.linspace(0, 1, 129))
    centers, levels = [], []
    for lo, hi in zip(edges[:-1], edges[1:]):
        chosen = valid & (temperatures >= lo) & (temperatures <= hi)
        if chosen.sum() >= 8 and hi > lo:
            centers.append(float(np.median(temperatures[chosen])))
            levels.append(float(np.median(lum[chosen])))
    if len(centers) < 16:
        raise AnalysisError("Недостатньо температурних деталей для підтвердження прев'ю.")
    predicted = np.interp(temperatures, centers, levels).astype(np.float32)
    difference = np.abs(predicted-lum)[valid]
    if allow_overlays:
        trimmed = valid & (np.abs(predicted-lum) < 18)
        if trimmed.sum()/valid.sum() < .92:
            raise AnalysisError("Забагато розбіжностей між прев'ю та RAW: відповідність не підтверджено.")
        valid = trimmed
        trimmed_rho = float(np.corrcoef(pd.Series(temperatures[valid]).rank(),
                                       pd.Series(lum[valid]).rank())[0,1])
        if abs(trimmed_rho) < .975:
            raise AnalysisError("Прев'ю не узгоджується з температурними деталями RAW.")
        # A one-pixel halo excludes anti-aliased edges of crosshairs/text
        # before ECC's smoothing step; the geometric tolerance stays unchanged.
        overlay = cv2.dilate((~trimmed).astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool)
        valid = trimmed & ~overlay
        if valid.sum()/trimmed.sum() < .90:
            raise AnalysisError("Забагато накладених позначок для перевірки геометрії FLIR.")
    elif np.percentile(difference, 95) > 12 or (difference > 28).mean() > .005:
        raise AnalysisError("Прев'ю містить зайві деталі або зміщення. Обведіть еталон з матриці.")
    try:
        score, warp = cv2.findTransformECC(predicted, lum, np.eye(2, 3, dtype=np.float32),
            cv2.MOTION_AFFINE, (cv2.TERM_CRITERIA_COUNT | cv2.TERM_CRITERIA_EPS, 100, 1e-6), valid.astype(np.uint8)*255, 5)
    except cv2.error as exc:
        raise AnalysisError("Не вдалося підтвердити геометрію FLIR-прев'ю.") from exc
    corners = np.array([[0,0,1], [w-1,0,1], [0,h-1,1], [w-1,h-1,1]], np.float32)
    if score < .98 or np.linalg.norm(corners @ warp.T-corners[:, :2], axis=1).max() > .7:
        raise AnalysisError("Прев'ю FLIR зміщене відносно RAW. Обведіть еталон з матриці.")
    return {"rank_correlation": rho, "preview_ecc": float(score), "preview_validation": "conservative_monotonic_palette_and_affine_check", "verified_roi_bounds": [x0,y0,x1,y1]}
