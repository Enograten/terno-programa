from pathlib import Path
import io
import json
import os
import shutil
import subprocess
import numpy as np
from PIL import Image
from .errors import AnalysisError

ROOT = Path(__file__).resolve().parents[1]
NO_RADIOMETRY = "У цьому файлі не знайдено радіометричних температурних даних. Точне визначення температури неможливе."


def find_exiftool(explicit=None):
    candidates = [explicit, os.environ.get("EXIFTOOL_PATH"), shutil.which("exiftool")]
    candidates += [str(p) for p in (ROOT / "tools").glob("**/exiftool*.exe") if "(-k)" not in p.name]
    candidates += [str(p) for p in (ROOT / "tools").glob("exiftool-*/exiftool")]
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return str(Path(candidate).resolve())
    raise AnalysisError("ExifTool не знайдено. Запустіть program/install_exiftool.ps1 або вкажіть EXIFTOOL_PATH.")


def run_exiftool(path, args, executable=None):
    command = [find_exiftool(executable)]
    if Path(command[0]).suffix.lower() != ".exe" and os.name == "nt":
        perl = os.environ.get("PERL_PATH") or shutil.which("perl")
        if not perl and Path("C:/Program Files/Git/usr/bin/perl.exe").is_file():
            perl = "C:/Program Files/Git/usr/bin/perl.exe"
        if not perl:
            raise AnalysisError("Perl unavailable; install standalone ExifTool for Windows.")
        command.insert(0, perl)
    try:
        completed = subprocess.run(
            [*command, *args, str(Path(path).resolve())],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=40, check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise AnalysisError("Не вдалося запустити ExifTool: " + str(exc)) from exc
    if completed.returncode != 0:
        detail = completed.stderr.decode("utf-8", errors="replace")[:300]
        raise AnalysisError("ExifTool не зміг прочитати файл. " + detail)
    return completed.stdout


def read_metadata(path, executable=None):
    payload = run_exiftool(path, ["-j", "-n", "-charset", "filename=UTF8"], executable)
    try:
        data = json.loads(payload.decode("utf-8"))
        metadata = data[0]
    except (ValueError, IndexError) as exc:
        raise AnalysisError("ExifTool повернув некоректні metadata.") from exc
    if "RawThermalImage" not in metadata:
        raise AnalysisError(NO_RADIOMETRY)
    return metadata


def decode_raw(data, metadata, byte_order="auto"):
    try:
        with Image.open(io.BytesIO(data)) as im:
            fmt = im.format
            raw = np.array(im)
    except Exception as exc:
        raise AnalysisError("Не вдалося декодувати RawThermalImage як 16-bit PNG/TIFF.") from exc
    if raw.ndim != 2 or raw.dtype.kind not in "ui" or raw.max() > 65535:
        raise AnalysisError("Очікується 16-бітна одноканальна RAW-матриця.")
    if raw.dtype.itemsize < 2:
        raise AnalysisError("RAW-матриця має лише 8 біт.")
    raw = raw.astype(np.uint16)
    expected = (int(metadata.get("RawThermalImageHeight", raw.shape[0])),
                int(metadata.get("RawThermalImageWidth", raw.shape[1])))
    if raw.shape != expected:
        raise AnalysisError("Розміри RawThermalImage не відповідають metadata.")
    if byte_order not in ("auto", "native", "swap"):
        raise AnalysisError("Невідомий порядок байтів.")
    # ExifTool documents the wrong byte order in many FLIR PNG payloads.
    # Resolve using camera's RAW median when available; otherwise require choice.
    if byte_order == "auto" and fmt == "PNG":
        median = metadata.get("RawValueMedian")
        if median is None:
            raise AnalysisError("FLIR PNG має неоднозначний порядок байтів. Вкажіть його у додаткових налаштуваннях.")
        med = float(median)
        choices = [raw, raw.byteswap()]
        distances = [abs(float(np.median(a))-med) for a in choices]
        order = np.argsort(distances)
        if distances[order[0]] > max(150, abs(med)*.03) or distances[order[1]]-distances[order[0]] < 200:
            raise AnalysisError("Не вдалося підтвердити порядок байтів FLIR PNG за RawValueMedian.")
        raw = choices[order[0]]
        selected = "swap" if order[0] else "native"
    elif byte_order == "swap":
        raw = raw.byteswap()
        selected = "swap"
    else:
        selected = "native"
    return raw, selected
