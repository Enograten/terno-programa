from dataclasses import dataclass, field, asdict
from pathlib import Path
import io
import cv2
import numpy as np
from PIL import Image
from .errors import AnalysisError
from .exiftool_reader import read_metadata, run_exiftool, decode_raw
from .temperature_conversion import Parameters, raw_to_celsius
from .visualization import thermal_rgb

MAX_PIXELS = 16_000_000


@dataclass
class ThermalData:
    temperatures: np.ndarray
    reference: np.ndarray
    filename: str
    source: str
    metadata: dict = field(default_factory=dict)
    original_preview: np.ndarray | None = None
    warnings: list = field(default_factory=list)


def read_rgb(data):
    try:
        with Image.open(io.BytesIO(data) if isinstance(data, bytes) else data) as im:
            if im.width*im.height > MAX_PIXELS:
                raise AnalysisError("Зображення завелике (максимум 16 мільйонів пікселів).")
            if im.getexif().get(274, 1) != 1:
                raise AnalysisError("Зображення має EXIF-поворот або віддзеркалення. Збережіть копію без зміни орієнтації.")
            return np.array(im.convert("RGB"))
    except AnalysisError:
        raise
    except Exception as exc:
        raise AnalysisError("Не вдалося прочитати зображення.") from exc


def validate_matrix(matrix):
    if matrix.ndim != 2 or min(matrix.shape) < 8 or matrix.size > MAX_PIXELS:
        raise AnalysisError("Потрібна двовимірна температурна матриця від 8×8 до 16 млн пікселів.")
    if matrix.dtype.kind not in "fiu":
        raise AnalysisError("Матриця повинна містити числа у °C.")
    matrix = matrix.astype(np.float64)
    if not np.isfinite(matrix).all() or matrix.min() <= -273.15:
        raise AnalysisError("Матриця містить недопустимі температури, NaN або Infinity.")
    return matrix


def load_matrix(path):
    path = Path(path)
    try:
        if path.suffix.lower() == ".npy":
            matrix = np.load(path, allow_pickle=False)
        elif path.suffix.lower() == ".npz":
            with np.load(path, allow_pickle=False) as archive:
                if "temperature_c" not in archive:
                    raise AnalysisError("NPZ повинен містити масив temperature_c.")
                matrix = archive["temperature_c"]
        else:
            matrix = np.loadtxt(path, delimiter="," if path.suffix.lower() == ".csv" else "\t")
        matrix = validate_matrix(matrix)
    except AnalysisError:
        raise
    except Exception as exc:
        raise AnalysisError("Не вдалося прочитати матрицю. CSV/TSV: тільки числа, без заголовка; десятковий роздільник — крапка.") from exc
    return ThermalData(matrix, thermal_rgb(matrix), path.name, "temperature_matrix_c",
                       {"units": "C", "matrix_shape": list(matrix.shape)})


def load_flir(path, executable=None, byte_order="auto", overrides=None):
    meta = read_metadata(path, executable)
    if int(meta.get("Orientation", 1)) != 1:
        raise AnalysisError("FLIR-файл має EXIF-поворот/віддзеркалення. Потрібен оригінал у координатах сенсора.")
    effective = dict(meta)
    if overrides:
        allowed = {"Emissivity", "ObjectDistance", "ReflectedApparentTemperature",
                   "AtmosphericTemperature", "IRWindowTemperature", "IRWindowTransmission", "RelativeHumidity"}
        if set(overrides)-allowed:
            raise AnalysisError("Непідтримуваний параметр ручної корекції.")
        effective.update(overrides)
    parameters = Parameters.from_metadata(effective)
    raw, selected = decode_raw(run_exiftool(path, ["-b", "-RawThermalImage"], executable), meta, byte_order)
    if raw.size > MAX_PIXELS:
        raise AnalysisError("RAW-матриця завелика.")
    matrix = raw_to_celsius(raw, parameters)
    preview = None
    try:
        preview = read_rgb(path)
    except AnalysisError:
        pass
    warnings = []
    if not np.isfinite(matrix).all():
        warnings.append("RAW містить недійсні пікселі. Області з такими пікселями не вимірюються.")
    metadata = {"flir": meta, "effective_parameters": asdict(parameters),
                "byte_order": selected, "overrides": overrides or {},
                "conversion": "FLIR LWIR, single atmospheric path; IR window at sensor"}
    return ThermalData(matrix, thermal_rgb(matrix), Path(path).name, "flir_radiometric",
                       metadata, preview, warnings)


def load_thermal(path, **kwargs):
    if Path(path).suffix.lower() in (".csv", ".tsv", ".npy", ".npz"):
        return load_matrix(path)
    return load_flir(path, **kwargs)
