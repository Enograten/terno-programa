"""Conservative recovery of existing thin green/cyan screenshot outlines.

RGB differences identify added ink only. Temperatures come from FLIR RAW;
every recovered screenshot mask requires user confirmation before measurement.
"""
import cv2
import numpy as np
from .errors import AnalysisError
from .contour_detector import enclosed_holes
from .green_roi import register_marked
from .mask_utils import validate_flir_preview


def detect_thin_regions(marked, registered, covered, min_area, max_gap=3):
    delta = marked.astype(np.float32) - registered.astype(np.float32)
    green_red = delta[:, :, 1] - delta[:, :, 0]
    blue_red = delta[:, :, 2] - delta[:, :, 0]
    # Relative channel changes survive anti-aliasing over both yellow and white.
    strong = (green_red > 20) & (blue_red > 30) & covered
    weak = (green_red > 8) & (blue_red > 12) & covered
    if strong.sum() < 30 or strong.mean() > .06:
        raise AnalysisError("Не знайдено чіткої доданої зеленої або блакитної лінії.")
    distance = cv2.distanceTransform((~strong).astype(np.uint8), cv2.DIST_L2, 5)
    # Weak pixels are allowed only within a few pixels of independently strong ink.
    radius = min(3, max(1, int(max_gap)))
    ink = strong | (weak & (distance <= radius))
    kernel = np.ones((int(max_gap)+2 | 1,)*2, np.uint8)
    closed = cv2.morphologyEx(ink.astype(np.uint8), cv2.MORPH_CLOSE, kernel) if max_gap else ink.astype(np.uint8)
    holes = enclosed_holes(closed, max(12, int(min_area)))
    regions = []
    boundaries = []
    for hole in holes:
        contours, _ = cv2.findContours(hole.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        contour = max(contours, key=cv2.contourArea)
        if cv2.contourArea(contour) < min_area:
            continue
        mask = np.zeros(hole.shape, np.uint8)
        cv2.drawContours(mask, [contour], -1, 1, cv2.FILLED)
        mask = mask.astype(bool)
        if (mask & ~covered).any():
            raise AnalysisError("Контур виходить за межі підтвердженого оригіналу.")
        if any((mask & other).any() for other in regions):
            raise AnalysisError("Тонкі контури вкладені або перетинаються.")
        rim = np.zeros(hole.shape, np.uint8)
        cv2.drawContours(rim, [contour], -1, 1, 1)
        # Do not close large missing segments or use thermal edges as boundaries.
        if np.mean(distance[rim > 0] <= radius+1) < .95 or np.max(distance[rim > 0]) > radius*2+2:
            raise AnalysisError("Частина тонкого контуру не підтверджена. Потрібна чіткіша замкнена лінія.")
        regions.append(mask)
        boundaries.append(rim.astype(bool))
    if not regions:
        raise AnalysisError("Тонкий контур не замкнений або надто нечіткий для визначення області.")
    # Any additional substantial stroke in the central picture is ambiguous.
    boundary_band = cv2.dilate(np.logical_or.reduce(boundaries).astype(np.uint8),
                               np.ones((2*radius+7,)*2, np.uint8)).astype(bool)
    unused = strong & ~boundary_band
    h, w = unused.shape
    unused[:round(h*.15)] = False
    unused[round(h*.9):] = False
    unused[:, :round(w*.03)] = False
    unused[:, round(w*.97):] = False
    _, _, stats, _ = cv2.connectedComponentsWithStats(unused.astype(np.uint8), connectivity=8)
    if len(stats) > 1 and stats[1:, cv2.CC_STAT_AREA].max() > max(100, int(strong.sum()*.1)):
        raise AnalysisError("Знайдено додаткову незамкнену лінію. Перевірте обведення.")
    # Verify unchanged image content outside a narrow ink exclusion band.
    valid = covered & ~cv2.dilate(ink.astype(np.uint8), np.ones((9, 9), np.uint8)).astype(bool)
    valid[:round(h*.15)] = False
    valid[round(h*.9):] = False
    valid[:, :round(w*.03)] = False
    valid[:, round(w*.97):] = False
    diff = np.max(np.abs(delta), axis=2)
    if valid.mean() < .35 or np.median(diff[valid]) > 12 or np.mean(diff[valid] < 35) < .90:
        raise AnalysisError("Обведена копія відрізняється від оригіналу поза контуром.")
    regions.sort(key=lambda mask: float(np.nonzero(mask)[1].mean()))
    return regions


def prepare_thin_regions(thermal, marked, min_area=80, max_gap=3):
    if thermal.original_preview is None:
        raise AnalysisError("Тонкий контур на готовій копії потребує оригінального FLIR JPEG.")
    preview = thermal.original_preview
    validation = validate_flir_preview(preview, thermal.temperatures,
                                      thermal.metadata.get("flir", {}), allow_overlays=True)
    registered, covered, transform, info = register_marked(preview, marked, thermal.temperatures.shape)
    scale = float(np.hypot(transform[0, 0], transform[1, 0]))
    area_scale = (scale*preview.shape[1]/thermal.temperatures.shape[1])**2
    masks = detect_thin_regions(marked, registered, covered, min_area*area_scale, max_gap)
    sensor_scale = np.diag([thermal.temperatures.shape[1]/preview.shape[1],
                            thermal.temperatures.shape[0]/preview.shape[0]])
    mapping = sensor_scale @ cv2.invertAffineTransform(transform)
    mapping[:, 2] += (np.diag(sensor_scale)-1)/2
    h, w = thermal.temperatures.shape
    allowed = np.zeros((h, w), bool)
    x0, y0, x1, y1 = validation["verified_roi_bounds"]
    allowed[y0:y1, x0:x1] = True
    regions = {}
    for index, mask in enumerate(masks, 1):
        mapped = cv2.warpAffine(mask.astype(np.uint8), mapping, (w, h),
                               flags=cv2.INTER_NEAREST).astype(bool)
        if mapped.sum() < min_area or (mapped & ~allowed).any():
            raise AnalysisError("Тонкий контур занадто малий або потрапляє на неперевірений край FLIR-прев'ю.")
        regions[f"Region {index}"] = mapped
    info.update({"reference": "flir_preview_thin_outline", "preview_validation": validation,
                 "marked_to_sensor_transform": mapping.tolist(), "geometry_confirmed": False,
                 "confirmation_reason": "Thin screenshot outline requires review of the recovered mask."})
    warnings = ["Тонкий контур зіставлено з RAW; потрібне підтвердження маски перед розрахунком."]
    return regions, info, warnings
