import cv2
import numpy as np
from .errors import AnalysisError

CONTOUR_ERROR = "Не вдалося однозначно визначити замкнену область. Перевірте обведення."
HUES = {"red": 0, "green": 60, "cyan": 90, "magenta": 150}


def colour_mask(rgb, color="red"):
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
    if color not in HUES:
        raise AnalysisError("Невідомий колір контуру.")
    hue = hsv[:, :, 0].astype(np.int16)
    distance = np.minimum(abs(hue-HUES[color]), 180-abs(hue-HUES[color]))
    return (distance <= 12) & (hsv[:, :, 1] >= 105) & (hsv[:, :, 2] >= 95)


def annotation_mask(marked, reference, color="red"):
    if reference.shape != marked.shape:
        reference = cv2.resize(reference, (marked.shape[1], marked.shape[0]), interpolation=cv2.INTER_LINEAR)
    delta = np.max(np.abs(marked.astype(np.int16)-reference.astype(np.int16)), axis=2)
    # Only ADDED ink, not existing red thermal areas.
    return colour_mask(marked, color) & (delta >= 24)


def enclosed_holes(ink, min_area):
    padded = np.pad(ink.astype(np.uint8), 1)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(1-padded, connectivity=4)
    outside = labels[0, 0]
    holes = []
    for label in range(1, count):
        if label != outside and stats[label, cv2.CC_STAT_AREA] >= min_area:
            holes.append(labels[1:-1, 1:-1] == label)
    return holes


def detect_regions(marked, reference, color="red", max_gap=3, min_area=80):
    ink = annotation_mask(marked, reference, color)
    if ink.sum() < 12 or ink.mean() > .22:
        raise AnalysisError(CONTOUR_ERROR + " Намалюйте тонку контрастну лінію.")
    min_area = max(12, int(min_area))
    original_holes = enclosed_holes(ink, min_area)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (max_gap+2 | 1, max_gap+2 | 1))
    closed = cv2.morphologyEx(ink.astype(np.uint8), cv2.MORPH_CLOSE, kernel) if max_gap else ink.astype(np.uint8)
    holes = enclosed_holes(closed, min_area)
    if not holes:
        raise AnalysisError(CONTOUR_ERROR)
    count, strokes, stats, _ = cv2.connectedComponentsWithStats(closed, connectivity=8)
    used = {}
    for hole in holes:
        rim = cv2.dilate(hole.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool) & ~hole
        touched = set(np.unique(strokes[rim]))-{0}
        if len(touched) != 1:
            raise AnalysisError(CONTOUR_ERROR + " Контури не повинні вкладатися один в один.")
        label = touched.pop()
        if label in used:
            raise AnalysisError(CONTOUR_ERROR + " Контури перетинаються або мають кілька внутрішніх частин.")
        used[label] = True
    for label in range(1, count):
        area = stats[label, cv2.CC_STAT_AREA]
        if label not in used and area >= max(30, min_area//2):
            raise AnalysisError(CONTOUR_ERROR + " Знайдено також незамкнену лінію.")
        if label in used:
            stroke = strokes == label
            if stroke[0].any() or stroke[-1].any() or stroke[:, 0].any() or stroke[:, -1].any():
                raise AnalysisError(CONTOUR_ERROR + " Контур торкається краю зображення.")
    holes.sort(key=lambda m: (float(np.nonzero(m)[1].mean()), float(np.nonzero(m)[0].mean())))
    regions = {f"Region {i+1}": mask for i, mask in enumerate(holes)}
    warnings = []
    if len(holes) > len(original_holes):
        warnings.append(f"Малий розрив контуру замкнено автоматично (налаштування: {max_gap} px). Перевірте маску.")
    return regions, ink, warnings
