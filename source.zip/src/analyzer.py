from dataclasses import dataclass, field
from datetime import datetime, timezone
import hashlib
import uuid
import numpy as np
from .errors import AnalysisError
from .mask_utils import verify_pair, resize_mask, validate_flir_preview
from .contour_detector import detect_regions
from .visualization import overlay_regions


def statistics(temperatures, mask, threshold):
    if temperatures.shape != mask.shape or mask.dtype != bool or not mask.any():
        raise AnalysisError("Некоректна або порожня маска.")
    values = temperatures[mask]
    if not np.isfinite(values).all() or not np.isfinite(threshold):
        raise AnalysisError("У вибраній області є недійсні температурні пікселі.")
    p5, p25, p75, p95 = np.percentile(values, [5, 25, 75, 95])
    return {"mean_temperature": float(values.mean()), "median_temperature": float(np.median(values)),
            "min_temperature": float(values.min()), "max_temperature": float(values.max()),
            "temperature_range_c": float(values.max() - values.min()),
            "std": float(values.std(ddof=0)), "p5": float(p5), "p25": float(p25),
            "p75": float(p75), "p95": float(p95), "pixel_count": int(values.size),
            "threshold_c": float(threshold), "hot_area_percentage": float(100*np.mean(values > threshold))}


def compare_regions(first, second):
    a, b = first["mean_temperature"], second["mean_temperature"]
    # Kelvin avoids an arbitrary percentage that depends on the Celsius zero.
    denominator = ((a+273.15)+(b+273.15))/2
    return {"region_a": first["region_id"], "region_b": second["region_id"],
            "difference_c": a-b, "absolute_asymmetry_c": abs(a-b),
            "percentage_difference_kelvin": 100*abs(a-b)/denominator}


@dataclass
class Analysis:
    thermal: object
    regions: dict
    reference: np.ndarray
    geometry: dict
    warnings: list = field(default_factory=list)
    analysis_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    marked_sha256: str = ""

    def confirm_geometry(self):
        self.geometry["geometry_confirmed"] = True
        self.geometry["confirmed_at"] = datetime.now(timezone.utc).isoformat()
        self.warnings = [message for message in self.warnings if "потрібне підтвердження" not in message]
        self.warnings.append("Результат розрахований після підтвердження розташування готового контуру.")
        return self

    def rows(self, selected, threshold, names=None):
        if self.geometry.get("requires_confirmation") and not self.geometry.get("geometry_confirmed"):
            raise AnalysisError("Спочатку підтвердьте розташування маски на термограмі.")
        names = names or {}
        return [{"region_id": key, "region_name": names.get(key, key),
                 **statistics(self.thermal.temperatures, self.regions[key], threshold)} for key in selected]

    def overlay(self, selected):
        return overlay_regions(self.reference, {key: self.regions[key] for key in selected})


def _analyze_line(thermal, marked, color="red", max_gap=3, min_area=80):
    references = [("matrix_reference", thermal.reference, {})]
    if thermal.original_preview is not None:
        try:
            verified = validate_flir_preview(thermal.original_preview, thermal.temperatures,
                                              thermal.metadata.get("flir", {}))
            references.append(("flir_preview", thermal.original_preview, verified))
        except AnalysisError:
            pass
    last_error = None
    for name, ref, detail in references:
        try:
            geometry = verify_pair(ref, marked, color)
        except AnalysisError as exc:
            last_error = exc
            continue
        area_scale = marked.shape[0]*marked.shape[1]/thermal.temperatures.size
        regions, _, warnings = detect_regions(marked, ref, color, max_gap, round(min_area*area_scale))
        mapped = {key: resize_mask(mask, thermal.temperatures.shape) for key, mask in regions.items()}
        if name == "flir_preview":
            x0,y0,x1,y1 = detail["verified_roi_bounds"]
            allowed = np.zeros(thermal.temperatures.shape, dtype=bool)
            allowed[y0:y1,x0:x1] = True
            if any((mask & ~allowed).any() for mask in mapped.values()):
                raise AnalysisError("Область заходить у край прев'ю FLIR, де можуть бути шкала та написи. Обведіть еталон, експортований із матриці.")
            warnings.append("Перевірено центральну thermal-частину прев'ю FLIR. Маска не перетинає рамку та шкалу.")
        import cv2
        reference = cv2.resize(ref, (thermal.temperatures.shape[1], thermal.temperatures.shape[0]),
                               interpolation=cv2.INTER_AREA)
        return Analysis(thermal, mapped, reference, {"reference": name, **geometry, **detail},
                        list(thermal.warnings)+warnings,
                        marked_sha256=hashlib.sha256(marked.tobytes()).hexdigest())
    raise AnalysisError(str(last_error or "Неможливо зіставити зображення.") +
                        " Завантажте еталон для обведення з програми та намалюйте контур на ньому.")


def analyze(thermal, marked, color="red", max_gap=3, min_area=80, annotation_style="auto"):
    if annotation_style not in ("auto","line","green_handles","thin_line"):
        raise AnalysisError("Невідомий тип обведення.")
    line_error = None
    if annotation_style not in ("green_handles", "thin_line"):
        try:
            return _analyze_line(thermal, marked, color, max_gap, min_area)
        except AnalysisError as exc:
            line_error = exc
            if annotation_style == "line":
                raise
    from .green_roi import find_handles, prepare_green_regions
    from .thin_roi import prepare_thin_regions
    use_thin = annotation_style == "thin_line"
    if annotation_style == "auto":
        try:
            find_handles(marked)
        except AnalysisError:
            use_thin = True
    if use_thin:
        try:
            regions, geometry, warnings = prepare_thin_regions(thermal, marked, min_area, max_gap)
        except AnalysisError:
            if annotation_style == "auto" and line_error is not None:
                raise line_error
            raise
    else:
        regions, geometry, warnings = prepare_green_regions(thermal, marked, min_area)
    return Analysis(thermal, regions, thermal.reference, geometry, list(thermal.warnings)+warnings,
                    marked_sha256=hashlib.sha256(marked.tobytes()).hexdigest())
