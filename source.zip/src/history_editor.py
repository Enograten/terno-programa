"""Local saved-history controls. Measured statistics remain read-only."""
from datetime import date
import streamlit as st
from .storage import edit_history_record
from .errors import AnalysisError


HISTORY_EDITOR_VERSION = 2


def history_editor(root, records, selected=None, edit_record=None, backup_notice=True):
    edit_record = edit_record or edit_history_record
    entry = next(((record, region) for record in records for region in record['regions']
                  if (record.get('_history_key'), region['region_id']) == selected), None)
    if entry is None:
        st.caption("Натисніть на рядок таблиці, щоб редагувати або видалити запис.")
        return
    record, region = entry
    selected = str(selected)
    with st.container(border=True):
        st.subheader(f"Редагування: {region['region_name']}")
        st.caption(f"{record['patient_id']} · {record['measurement_date']} · {record['original_file_name']}")
        version = record.get("updated_at", "")
        suffix = selected + version
        st.caption("Температурні показники не редагуються. Учасник, дата, сеанс і умови змінюються для всіх ділянок цього збереженого аналізу; назва — лише для обраної ділянки.")
        with st.form("history_edit_form" + suffix):
            left, right = st.columns(2)
            patient = left.text_input("Учасник", value=record['patient_id'])
            measured = right.date_input("Дата вимірювання", value=date.fromisoformat(record['measurement_date']))
            name = left.text_input("Назва ділянки", value=region['region_name'])
            session_value = right.text_input("Сеанс", value=record.get('session', ''))
            conditions = st.text_area("Умови вимірювання", value=record.get('measurement_conditions', ''))
            submitted = st.form_submit_button("Зберегти зміни")
        if submitted:
            try:
                edit_record(root, record, region['region_id'], dict(patient_id=patient,
                    measurement_date=str(measured), region_name=name, session=session_value,
                    measurement_conditions=conditions))
                st.session_state['history_notice'] = "Зміни збережено."
                st.session_state["history_reset_filters"] = True
                st.rerun()
            except (AnalysisError, ValueError, OSError) as error:
                st.error(str(error))
        confirmed = st.checkbox("Підтверджую видалення обраної ділянки з історії", key="history_delete_confirm"+suffix)
        if st.button("Видалити запис", disabled=not confirmed, key="history_delete"+suffix):
            try:
                edit_record(root, record, region['region_id'], delete=True)
                st.session_state['history_notice'] = "Запис видалено з історії." + (" Резервна копія залишилася на комп’ютері." if backup_notice else "")
                st.session_state.pop('history_active_row', None)
                st.rerun()
            except (AnalysisError, OSError) as error:
                st.error(str(error))
