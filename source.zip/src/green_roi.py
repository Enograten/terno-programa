"""Read an existing pale-green polygon with circular editing handles.

The translucent fill only orders the visible handles. Measurements are always
from FLIR RAW. Cropped/offset screenshots require explicit mask confirmation.
"""
import cv2
import numpy as np
from .errors import AnalysisError
from .mask_utils import validate_flir_preview


def find_handles(image):
    hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
    green = ((hsv[:, :, 0] >= 47) & (hsv[:, :, 0] <= 73) &
             (hsv[:, :, 1] >= 35) & (hsv[:, :, 1] <= 125) &
             (hsv[:, :, 2] >= 135)).astype(np.uint8)
    green = cv2.morphologyEx(green, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(3,3)))
    count, labels, stats, centers = cv2.connectedComponentsWithStats(green, connectivity=4)
    # Estimate marker size from compact blobs; do not depend on a particular screenshot size.
    compact = [stats[i, 4] for i in range(1, count)
               if 18 <= stats[i, 4] <= image.shape[0]*image.shape[1]*.003
               and .8 < stats[i, 2]/stats[i, 3] < 1.25
               and .55 < stats[i, 4]/(stats[i, 2]*stats[i, 3]) < .95]
    if len(compact) < 6:
        raise AnalysisError("Не знайдено достатньо зелених круглих точок. Завантажте копію з готовим контуром.")
    area = float(np.median(compact))
    radius = np.sqrt(area/np.pi)
    points = []
    for i in range(1, count):
        x, y, w, h, size = stats[i]
        if not .45*area <= size <= 2.8*area or min(w,h) < radius*1.25 or max(w,h) > radius*5:
            continue
        if size < 1.45*area and .7 < w/h < 1.45:
            points.append(centers[i])
            continue
        local = np.pad((labels[y:y+h, x:x+w] == i).astype(np.uint8), 1)
        distance = cv2.distanceTransform(local, cv2.DIST_L2, 5)
        k = max(3, round(radius) | 1)
        peaks = (distance >= cv2.dilate(distance, np.ones((k,k), np.uint8))-.01) & (distance >= radius*.60)
        _, _, _, locations = cv2.connectedComponentsWithStats(peaks.astype(np.uint8))
        for px, py in locations[1:]:
            points.append([x+px-1, y+py-1])
    points = np.asarray(points, dtype=np.float32)
    if len(points) < 6:
        raise AnalysisError("Зелені точки недостатньо чіткі для відновлення контуру.")
    colors = [image[round(y), round(x)] for x,y in points]
    return points, radius, np.median(colors, axis=0)


def register_marked(preview, marked, sensor_shape):
    if min(preview.shape[:2]) < 48:
        raise AnalysisError("Недостатня деталізація оригіналу для зіставлення готової розмітки.")
    detector = cv2.SIFT_create(nfeatures=2500, contrastThreshold=.015)
    first, a = detector.detectAndCompute(cv2.cvtColor(preview, cv2.COLOR_RGB2GRAY), None)
    second, b = detector.detectAndCompute(cv2.cvtColor(marked, cv2.COLOR_RGB2GRAY), None)
    if a is None or b is None:
        raise AnalysisError("Неможливо зіставити готову розмітку з оригіналом.")
    matches = cv2.BFMatcher().knnMatch(a,b,k=2)
    good = [pair[0] for pair in matches if len(pair)==2 and pair[0].distance < .7*pair[1].distance]
    if len(good) < 14:
        raise AnalysisError("Замало однакових деталей. Обведене зображення має бути копією цього самого кадру.")
    source = np.float32([first[g.queryIdx].pt for g in good])
    target = np.float32([second[g.trainIdx].pt for g in good])
    # Similarity only: no projective deformation and no reflection.
    tolerance = max(1.5, marked.shape[1]/preview.shape[1]*.8)
    transform, inliers = cv2.estimateAffinePartial2D(source,target,method=cv2.RANSAC,
                            ransacReprojThreshold=tolerance,maxIters=5000,confidence=.999)
    if transform is None or inliers is None:
        raise AnalysisError("Не вдалося підтвердити відповідність кадрів.")
    chosen = inliers.ravel().astype(bool)
    if chosen.sum() < 12 or chosen.mean() < .60:
        raise AnalysisError("Геометрія неоднозначна: можливий інший кадр або змінені пропорції.")
    angle = float(np.degrees(np.arctan2(transform[1,0],transform[0,0])))
    scale = float(np.hypot(transform[0,0],transform[1,0]))
    if abs(angle) > .20 or not .25 <= scale <= 12:
        raise AnalysisError("Обведений кадр повернуто або сильно змінено. Потрібна копія без повороту та віддзеркалення.")
    extent = np.ptp(source[chosen],axis=0)/[preview.shape[1],preview.shape[0]]
    hull_fraction = cv2.contourArea(cv2.convexHull(source[chosen]))/(preview.shape[0]*preview.shape[1])
    if min(extent) < .60 or hull_fraction < .25:
        raise AnalysisError("Збіги зосереджені на малій ділянці. Відповідність усього кадру не підтверджена.")
    predicted = source @ transform[:,:2].T + transform[:,2]
    errors = np.linalg.norm(predicted-target,axis=1)[chosen]/scale*sensor_shape[1]/preview.shape[1]
    if np.median(errors) > .35 or np.percentile(errors,95) > .85:
        raise AnalysisError("Похибка зіставлення надто велика для температурних пікселів.")
    registered = cv2.warpAffine(preview,transform,(marked.shape[1],marked.shape[0]),flags=cv2.INTER_LINEAR)
    covered = cv2.warpAffine(np.ones(preview.shape[:2],np.uint8),transform,
                            (marked.shape[1],marked.shape[0]),flags=cv2.INTER_NEAREST).astype(bool)
    info = {"method":"feature_similarity_manual_confirmation", "matched_features":int(chosen.sum()),
            "feature_inlier_ratio":float(chosen.mean()), "rotation_deg":angle,
            "matching_median_error_sensor_px":float(np.median(errors)),
            "matching_p95_error_sensor_px":float(np.percentile(errors,95)),
            "preview_to_marked_transform":transform.tolist(), "requires_confirmation":True}
    return registered, covered, transform, info


def polygon_intersects_itself(points):
    def cross(a,b,c):
        u,v=b-a,c-a
        return float(u[0]*v[1]-u[1]*v[0])
    n=len(points)
    for i in range(n):
        a,b=points[i],points[(i+1)%n]
        for j in range(i+2,n):
            if i==0 and j==n-1:
                continue
            c,d=points[j],points[(j+1)%n]
            if cross(a,b,c)*cross(a,b,d) < -1e-5 and cross(c,d,a)*cross(c,d,b) < -1e-5:
                return True
    return False


def extract_polygons(marked, registered, covered, points, radius, tint, min_area):
    # Alpha and tint identify an existing selection overlay, never a temperature.
    direction = tint - registered.astype(np.float32)
    difference = marked.astype(np.float32)-registered
    alpha = np.sum(difference*direction,axis=2)/(np.sum(direction**2,axis=2)+1e-6)
    residual = np.sqrt(np.mean((difference-alpha[:,:,None]*direction)**2,axis=2))
    fill = ((alpha>.16)&(alpha<.65)&(residual<16)&covered).astype(np.uint8)
    k = max(3, int(radius*.5)|1)
    fill = cv2.morphologyEx(fill,cv2.MORPH_CLOSE,np.ones((k,k),np.uint8))
    contours,_=cv2.findContours(fill,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
    regions=[]
    used=set()
    for contour in sorted(contours,key=cv2.contourArea,reverse=True):
        if cv2.contourArea(contour) < min_area:
            continue
        boundary=contour[:,0,:]
        selected=[]
        for index,point in enumerate(points):
            distances=np.linalg.norm(boundary-point,axis=1)
            if distances.min() <= radius*2.5:
                selected.append((int(np.argmin(distances)), index, point))
        if len(selected)<6:
            continue
        selected.sort(key=lambda item:item[0])
        polygon=np.asarray([item[2] for item in selected],np.float32)
        if polygon_intersects_itself(polygon):
            raise AnalysisError("Порядок зелених точок неоднозначний: отримано самоперетин. Використайте чіткіший файл обведення.")
        mask=np.zeros(marked.shape[:2],np.uint8)
        encoded=np.round(polygon*256).astype(np.int32)
        cv2.fillPoly(mask,[encoded],1,shift=8)
        inside=mask.astype(bool)
        if inside.sum()<min_area or (inside & ~covered).sum()>max(3,inside.sum()*.001):
            raise AnalysisError("Контур виходить за межі підтвердженого оригінального кадру.")
        # The existing fill must corroborate the interior and most of its outline.
        if np.mean(fill[inside]) < .72:
            raise AnalysisError("Заливка та зелені точки не утворюють однозначну область.")
        distance=cv2.distanceTransform((1-fill).astype(np.uint8),cv2.DIST_L2,5)
        for p,q in zip(polygon,np.roll(polygon,-1,axis=0)):
            steps=max(2,int(np.linalg.norm(q-p)))
            segment=np.linspace(p,q,steps)
            x=np.clip(np.rint(segment[:,0]).astype(int),0,marked.shape[1]-1)
            y=np.clip(np.rint(segment[:,1]).astype(int),0,marked.shape[0]-1)
            if np.mean(distance[y,x] > radius*1.7) > .12:
                raise AnalysisError("Частина контуру не підтверджена на зображенні. Потрібне чіткіше обведення.")
        if any((inside & previous[0]).any() for previous in regions):
            raise AnalysisError("Зелені області перетинаються.")
        # Exclude the actual polygon line; editing handles are not extra selected area.
        cv2.polylines(mask,[encoded],True,0,max(1,round(radius*.25)),shift=8)
        regions.append((mask.astype(bool),polygon))
        used.update(item[1] for item in selected)
    if not regions:
        raise AnalysisError("Зелені точки знайдено, але їхній замкнений контур із заливкою не визначено.")
    if len(used)/len(points)<.85:
        raise AnalysisError("Частина зелених точок не належить знайденим областям. Перевірте обведення.")
    outside=covered.copy()
    for mask,_ in regions:
        outside &= ~cv2.dilate(mask.astype(np.uint8),np.ones((max(3,round(radius*5)|1),)*2,np.uint8)).astype(bool)
    # Exclude text/scale margins only for the visual photometric check.
    hh,ww=outside.shape
    outside[:round(hh*.15)]=False
    outside[round(hh*.90):]=False
    outside[:,:round(ww*.03)]=False
    outside[:,round(ww*.97):]=False
    rgb_error=np.abs(marked.astype(float)-registered).max(axis=2)
    if outside.mean()<.12 or np.median(rgb_error[outside])>12 or np.mean(rgb_error[outside]<35)<.85:
        raise AnalysisError("Фон обведеної копії не відповідає оригінальному кадру.")
    regions.sort(key=lambda item:float(item[1][:,0].mean()))
    return regions


def prepare_green_regions(thermal,marked,min_area=80):
    if thermal.original_preview is None:
        raise AnalysisError("Готова зелена розмітка потребує оригінального FLIR JPEG.")
    points,radius,tint=find_handles(marked)
    preview_validation=validate_flir_preview(thermal.original_preview,thermal.temperatures,
                                            thermal.metadata.get("flir",{}),allow_overlays=True)
    registered,covered,transform,info=register_marked(thermal.original_preview,marked,thermal.temperatures.shape)
    scale=np.hypot(transform[0,0],transform[1,0])
    area_scale=(scale*thermal.original_preview.shape[1]/thermal.temperatures.shape[1])**2
    polygons=extract_polygons(marked,registered,covered,points,radius,tint,max(100,min_area*area_scale))
    inverse=cv2.invertAffineTransform(transform)
    sensor_scale=np.diag([thermal.temperatures.shape[1]/thermal.original_preview.shape[1],
                          thermal.temperatures.shape[0]/thermal.original_preview.shape[0]])
    mapping=sensor_scale @ inverse
    mapping[:,2] += (np.diag(sensor_scale)-1)/2
    h,w=thermal.temperatures.shape
    mapped={}
    for index,(mask,polygon) in enumerate(polygons,1):
        m=cv2.warpAffine(mask.astype(np.uint8),mapping,(w,h),flags=cv2.INTER_NEAREST).astype(bool)
        if m.sum()<min_area:
            raise AnalysisError("Область занадто мала в температурній матриці.")
        mapped[f"Region {index}"]=m
    info.update({"reference":"flir_preview_green_handles","preview_validation":preview_validation,
                 "detected_handles":int(len(points)), "polygon_vertices":[len(p) for _,p in polygons],
                 "polygons_marked_pixels":[p.tolist() for _,p in polygons],
                 "marked_to_sensor_transform":mapping.tolist(),
                 "confirmation_reason":"Existing screenshot may be cropped or offset; measurements require review.",
                 "geometry_confirmed":False})
    warnings=["Готовий зелений контур зіставлено з RAW. Через обрізку/зміщення копії потрібне підтвердження маски перед розрахунком."]
    return mapped,info,warnings
